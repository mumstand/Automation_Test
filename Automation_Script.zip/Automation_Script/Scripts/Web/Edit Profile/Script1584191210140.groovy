import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

//==============================================================================
//	Call Private Method Function
//==============================================================================

Login_SehatQ()
Edit_Profile()

//==============================================================================
//	Private Function for Login 
//==============================================================================

private Login_SehatQ(){
	
//==============================================================================
//	Variable declaration for data input
//==============================================================================

	String Username = 'muhammad.iqbal.odn@gmail.com'
	String Password	= 'P@ssw0rd1'
	
//==============================================================================
//	Script for Edit Profile in SehatQ Application
//==============================================================================
	
	WebUI.openBrowser('')
	WebUI.maximizeWindow()
	WebUI.delay(2)
	WebUI.navigateToUrl('https://www.sehatq.com/')
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Login/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/i_Tidak ada notifikasi_fs icon-profile colo_658490'))
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Login/Page_Login/a_Continue with Email'))
	WebUI.delay(2)
	WebUI.setText(findTestObject('Object Repository/Web/Login/Page_Login/input_Email_email'), Username)
	WebUI.delay(2)
	WebUI.setText(findTestObject('Object Repository/Web/Login/Page_Login/input_show password_password'), Password)
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Login/Page_Login/button_Continue'))
	WebUI.delay(2)
	WebUI.verifyElementPresent(findTestObject('Object Repository/Web/Login/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/span_Welcome to SehatQ  Tanya Dokter dan Ti_fa6e7a'), 0)
}

private Edit_Profile(){
	
//==============================================================================
//	Variable declaration for data input
//==============================================================================

	String EditName = 'Muhammad Iqbal'
	
//==============================================================================
//	Private Function for Edit Profile in SehatQ Application
//==============================================================================
	
	WebUI.click(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/i_Profil_fs icon-edit color-primary font-16'))
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/div_Selamat Datang Iqbal     Settings      _5957ef'))
	WebUI.delay(2)
	WebUI.setText(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/input__name'), EditName)
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/button_Simpan'))
	WebUI.delay(2)
	WebUI.verifyElementVisible(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/span_Edit profile berhasil'))
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/img_Tidak ada notifikasi_img-circle'))
	WebUI.delay(2)
	WebUI.click(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/span_Sign Out'))
	WebUI.delay(3)
	WebUI.click(findTestObject('Object Repository/Web/Edit Profile/Page_SehatQ  Tanya Dokter dan Tips Keluarga Sehat/button_Ya'))
	WebUI.closeBrowser()
	
	
}

