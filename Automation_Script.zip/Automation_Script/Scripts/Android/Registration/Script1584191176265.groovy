import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

//==============================================================================
//	Call Private Method Function
//==============================================================================

Registration_Android()

//==============================================================================
//	Private Function for Registration 
//==============================================================================

private Registration_Android(){

	Mobile.startApplication('D:\\base.apk', true)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.TextView2 - Skip'), 0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.ImageView25'), 0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.TextView4'), 0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.RelativeLayout4'), 0)
	Mobile.delay(2)
	Mobile.setText(findTestObject('Android/Registration/android.widget.EditText0 - Type your full name'), 'Rian Andika', 0)
	Mobile.delay(2)
	Mobile.setText(findTestObject('Android/Registration/android.widget.EditText1 - exampleexample.com'), 'Rian@mail.com', 0)
	Mobile.delay(2)
	Mobile.setText(findTestObject('Android/Registration/android.widget.EditText2 - Minimum 6 karakter'), 'P@ssw0rd1', 0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.CheckBox0'), 0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.Button0 - Lanjutkan'), 0)
	Mobile.delay(2)
	Mobile.setText(findTestObject('Android/Registration/android.widget.EditText1 - Select your date of birth'), '1990-01-01',0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.RadioButton1 - Laki-laki'), 0)
	Mobile.delay(2)
	Mobile.tap(findTestObject('Android/Registration/android.widget.Button0 - Lanjutkan (1)'), 0)
	Mobile.delay(2)
	Mobile.closeApplication()
	
}