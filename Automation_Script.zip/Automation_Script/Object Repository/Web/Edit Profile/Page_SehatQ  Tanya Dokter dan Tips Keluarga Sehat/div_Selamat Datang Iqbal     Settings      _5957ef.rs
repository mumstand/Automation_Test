<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Selamat Datang Iqbal     Settings      _5957ef</name>
   <tag></tag>
   <elementGuidId>bd2450fa-6a36-47b5-baff-0a9302a65d37</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = '          Selamat Datang Iqbal     Settings          Keluarga      Aktivitas      Kalender      Health Record         Edit Profil                Edit        Nama Lengkap*      Tanggal lahir*         Jenis Kelamin*      Pria        Perempuan           Tinggi Badan (cm)      Berat Badan (kg)      Alamat*      No. Telepon*      Email*           Batal    Simpan                   Kumpulan Artikel dan Forum         Artikel Maret 2020     Artikel Februari 2020     Artikel Januari 2020     Artikel Desember 2019     Artikel November 2019     Artikel Oktober 2019     Artikel September 2019     Artikel Agustus 2019     Artikel Juli 2019     Artikel Juni 2019     Artikel Mei 2019     Artikel April 2019     Artikel Maret 2019     Artikel Februari 2019       Forum Maret 2020     Forum Februari 2020     Forum Januari 2020     Forum Desember 2019     Forum November 2019     Forum Oktober 2019     Forum September 2019     Forum Agustus 2019     Forum Juli 2019     Forum Juni 2019     Forum Mei 2019     Forum April 2019     Forum Maret 2019     Forum Februari 2019     Forum Januari 2019     Forum Desember 2018     Forum November 2018           Tentang Kami Syarat dan Ketentuan Karir Kontak Kami Privacy Policy Kebijakan Editorial Direktori Tag                         Langganan Newsletter Jadi orang yang pertama tahu info &amp; promosi kesehatan terbaru dari SehatQ. Gratis.   Jenis Kelamin     Perempuan      Pria      Email             © SehatQ, 2018. All Rights Reserved              ' or . = '          Selamat Datang Iqbal     Settings          Keluarga      Aktivitas      Kalender      Health Record         Edit Profil                Edit        Nama Lengkap*      Tanggal lahir*         Jenis Kelamin*      Pria        Perempuan           Tinggi Badan (cm)      Berat Badan (kg)      Alamat*      No. Telepon*      Email*           Batal    Simpan                   Kumpulan Artikel dan Forum         Artikel Maret 2020     Artikel Februari 2020     Artikel Januari 2020     Artikel Desember 2019     Artikel November 2019     Artikel Oktober 2019     Artikel September 2019     Artikel Agustus 2019     Artikel Juli 2019     Artikel Juni 2019     Artikel Mei 2019     Artikel April 2019     Artikel Maret 2019     Artikel Februari 2019       Forum Maret 2020     Forum Februari 2020     Forum Januari 2020     Forum Desember 2019     Forum November 2019     Forum Oktober 2019     Forum September 2019     Forum Agustus 2019     Forum Juli 2019     Forum Juni 2019     Forum Mei 2019     Forum April 2019     Forum Maret 2019     Forum Februari 2019     Forum Januari 2019     Forum Desember 2018     Forum November 2018           Tentang Kami Syarat dan Ketentuan Karir Kontak Kami Privacy Policy Kebijakan Editorial Direktori Tag                         Langganan Newsletter Jadi orang yang pertama tahu info &amp; promosi kesehatan terbaru dari SehatQ. Gratis.   Jenis Kelamin     Perempuan      Pria      Email             © SehatQ, 2018. All Rights Reserved              ')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='pageProfile']/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>          Selamat Datang Iqbal     Settings          Keluarga      Aktivitas      Kalender      Health Record         Edit Profil                Edit        Nama Lengkap*      Tanggal lahir*         Jenis Kelamin*      Pria        Perempuan           Tinggi Badan (cm)      Berat Badan (kg)      Alamat*      No. Telepon*      Email*           Batal    Simpan                   Kumpulan Artikel dan Forum         Artikel Maret 2020     Artikel Februari 2020     Artikel Januari 2020     Artikel Desember 2019     Artikel November 2019     Artikel Oktober 2019     Artikel September 2019     Artikel Agustus 2019     Artikel Juli 2019     Artikel Juni 2019     Artikel Mei 2019     Artikel April 2019     Artikel Maret 2019     Artikel Februari 2019       Forum Maret 2020     Forum Februari 2020     Forum Januari 2020     Forum Desember 2019     Forum November 2019     Forum Oktober 2019     Forum September 2019     Forum Agustus 2019     Forum Juli 2019     Forum Juni 2019     Forum Mei 2019     Forum April 2019     Forum Maret 2019     Forum Februari 2019     Forum Januari 2019     Forum Desember 2018     Forum November 2018           Tentang Kami Syarat dan Ketentuan Karir Kontak Kami Privacy Policy Kebijakan Editorial Direktori Tag                         Langganan Newsletter Jadi orang yang pertama tahu info &amp; promosi kesehatan terbaru dari SehatQ. Gratis.   Jenis Kelamin     Perempuan      Pria      Email             © SehatQ, 2018. All Rights Reserved              </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pageProfile&quot;)/div[@class=&quot;page-content pt-5&quot;]/div[@class=&quot;container&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='pageProfile']/div[2]/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Acara'])[1]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forum'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div</value>
   </webElementXpaths>
</WebElementEntity>
