<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Fahmi Nurbani     nurbanifahmigmailcom</name>
   <tag></tag>
   <elementGuidId>e4f0cb02-39fb-4cca-be3a-7b37f6e3b7a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;pageHome&quot;)/div[@class=&quot;page-content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-4 col-lg-3 js-stickySidebar&quot;]/div[@class=&quot;theiaStickySidebar&quot;]/div[@class=&quot;mb-4&quot;]/div[@class=&quot;section-box with-border&quot;]/div[@class=&quot;box-body mt-3 mt-sm-4&quot;]/div[@class=&quot;box-profile&quot;]/div[@class=&quot;row row-10&quot;]/div[@class=&quot;align-self-center col-12 text-center&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='pageHome']/div[2]/div[4]/div/div[2]/div/div/div/div[2]/div/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>align-self-center col-12 text-center</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>     Fahmi Nurbani     nurbanifahmi@gmail.com </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pageHome&quot;)/div[@class=&quot;page-content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-4 col-lg-3 js-stickySidebar&quot;]/div[@class=&quot;theiaStickySidebar&quot;]/div[@class=&quot;mb-4&quot;]/div[@class=&quot;section-box with-border&quot;]/div[@class=&quot;box-body mt-3 mt-sm-4&quot;]/div[@class=&quot;box-profile&quot;]/div[@class=&quot;row row-10&quot;]/div[@class=&quot;align-self-center col-12 text-center&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='pageHome']/div[2]/div[4]/div/div[2]/div/div/div/div[2]/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profil'])[2]/following::div[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='© SehatQ, 2018. All Rights Reserved'])[1]/following::div[16]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div[2]/div/div/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
